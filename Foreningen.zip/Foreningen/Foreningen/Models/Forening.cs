﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Foreningen.Models
{
    public class Forening
    {
        public int Id {get; set;}

        [Required]
        [Display(Name="Ordförandenamn")]
        public String OrdForandeName { get; set; }

        [Required]
        [Display(Name = "Föreningsnamn")]

        public String Name { get; set; }

        [Required]
        [Display(Name = "Antal medlemmar")]

        public int TotalMembers { get; set; }



}
}
