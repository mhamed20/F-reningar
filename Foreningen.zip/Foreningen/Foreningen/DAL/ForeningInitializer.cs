﻿using Foreningen.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Foreningen.DAL
{
    public static class DbInitializer
    {
        public static void Initialize(ForeningContext context)
        {
            context.Database.EnsureCreated();

            // Look for any students.
            if (context.Foreningar.Any())
            {
                return;   // DB has been seeded
            }
            var Foreningar = new List<Forening>
            {
            new Forening{OrdForandeName="Telia",Name="Jhon Adnsersson",TotalMembers=3},
            new Forening{OrdForandeName="Aplha",Name="Axel Svensson",TotalMembers=5},
            new Forening{OrdForandeName="The Road",Name="Ulf Gustavsson",TotalMembers=11},            };
        

            foreach (var f in Foreningar)
            context.Foreningar.Add(f);
            context.SaveChanges();
           
        }
    }
}