﻿using Foreningen.Models;
using Microsoft.EntityFrameworkCore;


namespace Foreningen.DAL
{
    public class ForeningContext : DbContext
    {
        public ForeningContext(DbContextOptions<ForeningContext> options) : base(options)
        {
        }

        public DbSet<Forening> Foreningar { get; set; }
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Forening>().ToTable("Forening");
        }
    }
}